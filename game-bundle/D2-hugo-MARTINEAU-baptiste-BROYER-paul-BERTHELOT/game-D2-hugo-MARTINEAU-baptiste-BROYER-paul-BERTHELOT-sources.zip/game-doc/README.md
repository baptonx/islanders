
Put in this folder:
- the user documentation of the app
- your modelling report and its pictures (svg or pdf)

